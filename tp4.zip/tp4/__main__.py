from interface.interface_othello import Brothello

"""
Module principal du package othello.
"""


if __name__ == '__main__':
    # Création d'une instance de Partie.
    le_jeu = Brothello()
    le_jeu.mainloop()
